"""
Баллистический симулятор в физических единицах (метры, секунды, м/с, м/с²).

Один и тот же файл работает двумя способами:
  1) Обычный запуск в PyCharm (шрифт LiberationSans-Regular.ttf должен лежать рядом с main.py).
  2) В браузере через Pygbag:
        python -m pip install pygbag
        python -m pygbag .            <- запускать в папке, где лежит main.py
     затем открыть http://localhost:8000
"""
import asyncio
import csv
import math
import random
import sys

import pygame

pygame.init()
pygame.font.init()

# Мы в браузере (Pygbag) или на обычном компьютере?
WEB = sys.platform == "emscripten"

# Размер 16:9 — как у большинства экранов, поэтому в полноэкранном режиме нет чёрных полос по бокам.
WIDTH, HEIGHT = 1280, 720

if WEB:
    # В браузере страница сама подгоняет холст под окно, дополнительные флаги не нужны.
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
else:
    # SCALED    — рисуем в «виртуальном» окне 1280x720, pygame растягивает его под реальный размер.
    # RESIZABLE — окно можно тянуть мышкой и разворачивать кнопкой «□». F11 — полный экран.
    screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.SCALED | pygame.RESIZABLE)
pygame.display.set_caption("Баллистический симулятор — Полная версия")
clock = pygame.time.Clock()

# В браузере системных шрифтов (Arial) нет, поэтому берём шрифт из файла рядом с программой.
FONT_FILE = "LiberationSans-Regular.ttf"


def load_font(size):
    try:
        return pygame.font.Font(FONT_FILE, size)
    except (FileNotFoundError, OSError):
        return pygame.font.SysFont("Arial", size)  # запасной вариант на обычном компьютере


font = load_font(20)
small_font = load_font(16)

# --- 1. ФИЗИЧЕСКИЕ ЕДИНИЦЫ ---
# Компьютер считает в пикселях и кадрах, а в метры и секунды всё переводится через два числа:
PX_PER_M = 20   # масштаб: 1 метр = 20 пикселей
DT = 1 / 60     # шаг времени: один кадр = 1/60 секунды (на 60 FPS время идёт как в жизни)

# Ускорение времени (клавиша T): сколько шагов физики делается за один кадр.
# Нужно потому, что в реальных единицах, например, навесной выстрел на Луне летит около 30 секунд.
WARP_LEVELS = [1, 2, 4, 8]

# --- 2. ПАРАМЕТРЫ СИМУЛЯЦИИ ---
angle_deg = 50.0
velocity = 22.0  # начальная скорость, м/с
floor_y = 640  # Земля; под ней остаётся место для текста
ball_radius = 15
start_x, start_y = 50.0, float(floor_y - ball_radius)

PLANETS = {  # ускорение свободного падения g, м/с²
    "Земля": {"g": 9.81},
    "Луна": {"g": 1.62},
    "Марс": {"g": 3.71}
}
current_planet = "Земля"
use_air_drag = False

# Сопротивление воздуха: a = -c·|v|·v, где c = ρ·Cd·S/(2m), измеряется в 1/м.
# 0.03 1/м — примерно как у лёгкого большого мяча.
drag_c = 0.03
k_drag = drag_c / PX_PER_M  # тот же коэффициент, но для пикселей и кадров (вывод формулы — в отчёте)

# Потолок скорости для автоприцела. На 60 м/с шарик за кадр пролетает 20 px — это меньше ширины
# «зоны столкновения» со стеной (25 + 30 px), поэтому сквозь стену он не проскочит.
AUTO_V_MAX = 60

# Мишень
target_pos = [800, 520]
target_radius = 25
hit_target = False

# Стена
wall_height = 290
wall_rect = pygame.Rect(450, floor_y - wall_height, 25, wall_height)
wall_visible = True
wall_moving = False
wall_dir = 1
hit_wall = False
WALL_STEP = 3  # пикселей за шаг (это 9 м/с)

# Статистика и интерфейс
t_flight = 0  # время полёта в шагах (секунды = шаги · DT)
max_h = 0.0   # максимальная высота над уровнем выстрела, px
flight_dist = 0.0

# Сообщения на экране (ошибки красным, подсказки жёлтым, успех зелёным)
RED = (255, 50, 50)
YELLOW = (255, 215, 0)
GREEN = (150, 250, 150)
message_text = ""
message_color = RED
message_timer = 0

# Состояние снаряда
x, y, v_x, v_y, trail, is_flying = start_x, start_y, 0, 0, [], False

# Подсказки по клавишам рисуются один раз (текст не меняется, незачем перерисовывать его каждый кадр)
controls_1 = "ПРОБЕЛ: Выстрел | СТРЕЛКИ: Наводка | F: Автоприцел | R: Случайная мишень | T: Ускорение"
controls_2 = "СТЕНА -> W: Вкл/Выкл | M: Движение | Z/X: Влево/Вправо | U/I: Выше/Ниже"
if not WEB:
    controls_1 += " | S: Сохранить в CSV"
    controls_2 += " | F11: Во весь экран"
controls_surf_1 = small_font.render(controls_1, True, (180, 180, 180))
controls_surf_2 = small_font.render(controls_2, True, (180, 180, 180))


def g_px():
    """Ускорение свободного падения в пикселях за шаг²: g[м/с²] · (пикс/м) · (с/шаг)²."""
    return PLANETS[current_planet]["g"] * PX_PER_M * DT ** 2


def speed_px(v_ms):
    """Скорость из м/с в пиксели за шаг: v[м/с] · (пикс/м) · (с/шаг)."""
    return v_ms * PX_PER_M * DT


def show_message(text, color=RED, frames=240):
    """Показывает сообщение под статистикой на frames кадров (240 кадров = 4 секунды)."""
    global message_text, message_color, message_timer
    message_text = text
    message_color = color
    message_timer = frames


def reset_ball():
    global hit_target, hit_wall, t_flight, max_h, flight_dist
    hit_target = False
    hit_wall = False
    t_flight = 0
    max_h = 0.0
    flight_dist = 0.0
    angle_rad = math.radians(angle_deg)
    v0 = speed_px(velocity)
    v_x = v0 * math.cos(angle_rad)
    v_y = -v0 * math.sin(angle_rad)
    return start_x, start_y, v_x, v_y, [], True


def step_wall(rect, direction):
    """Один шаг движения стены. Двигает rect и возвращает направление (вверх/вниз).
    Эту функцию используют и настоящая игра, и «пробные выстрелы» — поэтому они двигают стену одинаково."""
    rect.y += WALL_STEP * direction
    if rect.y < 100 or rect.bottom > floor_y:
        direction *= -1
    return direction


def simulate_flight(angle, vel, max_steps=8000):
    """Пробный выстрел: прогоняет полёт «в уме» ТЕМИ ЖЕ формулами, что и настоящий.
    Учитывает воздух, планету, стену (в том числе движущуюся) и мишень.
    Возвращает (точки_траектории, результат), где результат:
    "target" — попали в мишень, "wall" — врезались в стену,
    "ground" — упали на землю, "timeout" — не приземлились за max_steps шагов."""
    rad = math.radians(angle)
    px, py = start_x, start_y
    v0 = speed_px(vel)
    pvx = v0 * math.cos(rad)
    pvy = -v0 * math.sin(rad)
    g = g_px()

    wall = wall_rect.copy()  # копия, чтобы пробный выстрел не двигал настоящую стену
    wdir = wall_dir
    pts = []
    result = "timeout"

    for _ in range(max_steps):
        if wall_moving and wall_visible:
            wdir = step_wall(wall, wdir)

        if use_air_drag:
            spd = math.hypot(pvx, pvy)
            pvx -= k_drag * pvx * spd
            pvy -= k_drag * pvy * spd
        pvy += g
        px += pvx
        py += pvy

        if len(pts) == 0 or math.hypot(px - pts[-1][0], py - pts[-1][1]) > 20:
            pts.append((int(px), int(py)))

        if math.hypot(px - target_pos[0], py - target_pos[1]) <= ball_radius + target_radius:
            result = "target"
            break
        # То же самое, что colliderect() для квадрата вокруг шарика, но без создания Rect на каждом шаге
        # (так быстрее, а в браузере Python медленнее обычного).
        bx, by = int(px), int(py)
        if (wall_visible
                and bx - ball_radius < wall.right and bx + ball_radius > wall.left
                and by - ball_radius < wall.bottom and by + ball_radius > wall.top):
            result = "wall"
            break
        if py >= floor_y - ball_radius:
            result = "ground"
            break
    return pts, result


def formula_angles(vel):
    """Формула (полёт БЕЗ воздуха), всё в метрах и м/с: какие углы при скорости vel ведут в центр мишени.
    Обычно их два: настильный (малый угол, быстрый) и навесной (большой угол, долгий).
    Если мишень слишком далеко или высоко для этой скорости — вернёт пустой список."""
    x_t = (target_pos[0] - start_x) / PX_PER_M   # расстояние до мишени, м
    y_t = (start_y - target_pos[1]) / PX_PER_M   # высота мишени над пушкой, м
    g = PLANETS[current_planet]["g"]
    if x_t <= 0:
        return []

    a = (g * x_t ** 2) / (2 * vel ** 2)
    D = x_t ** 2 - 4 * a * (a + y_t)
    if D < 0:
        return []

    root = math.sqrt(D)
    angles = {math.degrees(math.atan((x_t + sign * root) / (2 * a))) for sign in (1, -1)}
    return sorted(ang for ang in angles if 1 <= ang <= 89)


def analyze_shots(vel):
    """Берём углы из формулы и проверяем каждый пробным выстрелом.
    Возвращает список пар (угол, результат), отсортированный по углу."""
    return [(ang, simulate_flight(ang, vel)[1]) for ang in formula_angles(vel)]


def auto_aim():
    global angle_deg, velocity

    shots = analyze_shots(velocity)
    good = [ang for ang, result in shots if result == "target"]
    walled = any(result == "wall" for ang, result in shots)

    # 1) При текущей скорости есть чистая траектория -> переключаемся между ними по кругу.
    #    Первой всегда идёт быстрая настильная (малый угол), потом навесная.
    if good:
        idx = next((i for i, ang in enumerate(good) if abs(ang - angle_deg) < 0.05), None)
        angle_deg = good[0] if idx is None else good[(idx + 1) % len(good)]
        if len(good) == 1:
            if walled:
                show_message("Вторая траектория упирается в стену — осталась только эта", YELLOW)
            else:
                show_message("При этой скорости есть только одна траектория", YELLOW)
        return

    # 2) Чистой траектории нет (мишень далеко/высоко или обе дуги упираются в стену).
    #    Пробуем прибавлять скорость и берём первую (самую маленькую), при которой получится.
    old_v = velocity
    for v in range(int(velocity) + 1, AUTO_V_MAX + 1):
        good = [ang for ang, result in analyze_shots(float(v)) if result == "target"]
        if good:
            velocity = float(v)
            angle_deg = good[0]
            if walled:
                show_message(f"Стена мешает — поставил скорость {v} м/с, чтобы перелететь", YELLOW)
            else:
                show_message(f"Для {old_v:.0f} м/с не хватает дальности — поставил {v} м/с", YELLOW)
            return

    # 3) Решения нет совсем — честно говорим об этом.
    hint = " Уберите стену [W] или опустите [I]" if wall_visible else ""
    show_message(f"Решения нет даже на {AUTO_V_MAX} м/с." + hint, RED)


def target_in_wall_column(pos):
    """True, если мишень попала бы в «колонну» стены (стена ездит вверх-вниз, поэтому берём всю высоту)."""
    return wall_visible and wall_rect.left - target_radius < pos[0] < wall_rect.right + target_radius


def save_trail_to_csv():
    """Сохраняет траекторию в метрах и секундах. x и y отсчитываются от пушки (y — высота над ней)."""
    with open("trajectory_data.csv", "w", newline='') as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(["t_s", "x_m", "y_m"])
        for pt in trail:
            writer.writerow([round(pt[2] * DT, 3),
                             round((pt[0] - start_x) / PX_PER_M, 3),
                             round((start_y - pt[1]) / PX_PER_M, 3)])


async def main():
    # Главный цикл теперь внутри async-функции (так требует Pygbag).
    # Все глобальные переменные, которым мы ПРИСВАИВАЕМ новые значения, надо перечислить здесь.
    global x, y, v_x, v_y, trail, is_flying
    global angle_deg, velocity, use_air_drag, current_planet
    global target_pos, wall_visible, wall_moving, wall_dir
    global hit_target, hit_wall, t_flight, max_h, flight_dist, message_timer

    # Фантом пересчитываем только когда что-то поменялось (иначе — берём прошлый результат)
    phantom_key = None
    phantom_pts = []
    warp_idx = 0  # номер выбранного ускорения времени в WARP_LEVELS

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    x, y, v_x, v_y, trail, is_flying = reset_ball()
                elif event.key == pygame.K_UP:
                    angle_deg = min(89.0, angle_deg + 1.0)
                elif event.key == pygame.K_DOWN:
                    angle_deg = max(1.0, angle_deg - 1.0)
                elif event.key == pygame.K_RIGHT:
                    velocity += 1.0
                elif event.key == pygame.K_LEFT:
                    velocity = max(1.0, velocity - 1.0)
                elif event.key == pygame.K_a:
                    use_air_drag = not use_air_drag
                elif event.key == pygame.K_t:
                    warp_idx = (warp_idx + 1) % len(WARP_LEVELS)
                elif event.key == pygame.K_1:
                    current_planet = "Земля"
                elif event.key == pygame.K_2:
                    current_planet = "Луна"
                elif event.key == pygame.K_3:
                    current_planet = "Марс"

                elif event.key == pygame.K_w:
                    wall_visible = not wall_visible
                elif event.key == pygame.K_m:
                    wall_moving = not wall_moving
                elif event.key == pygame.K_z:
                    wall_rect.x -= 20
                elif event.key == pygame.K_x:
                    wall_rect.x += 20
                elif event.key == pygame.K_u:
                    new_height = wall_rect.height + 20
                    wall_rect.height = new_height
                    wall_rect.y = floor_y - new_height
                elif event.key == pygame.K_i:
                    new_height = max(20, wall_rect.height - 20)
                    wall_rect.height = new_height
                    wall_rect.y = floor_y - new_height
                elif event.key == pygame.K_r:
                    # Не ставим мишень внутрь стены
                    while True:
                        target_pos = [random.randint(500, WIDTH - 80), random.randint(200, 600)]
                        if not target_in_wall_column(target_pos):
                            break
                elif event.key == pygame.K_f:
                    if use_air_drag:
                        show_message("Математическая ошибка: Формула автоприцела работает только в вакууме!", RED)
                    else:
                        auto_aim()
                elif event.key == pygame.K_F11 and not WEB:
                    pygame.display.toggle_fullscreen()
                elif event.key == pygame.K_s and not is_flying and trail:
                    if WEB:
                        show_message("В браузерной версии сохранение в CSV недоступно", YELLOW)
                    else:
                        save_trail_to_csv()
                        show_message("Сохранено в trajectory_data.csv", GREEN, 120)

        if message_timer > 0:
            message_timer -= 1

        # --- ФИЗИКА: за один кадр делаем WARP_LEVELS[warp_idx] шагов (ускорение времени) ---
        g = g_px()
        for _ in range(WARP_LEVELS[warp_idx]):
            # Движение стены
            if wall_moving and wall_visible:
                wall_dir = step_wall(wall_rect, wall_dir)

            if is_flying:
                t_flight += 1
                if use_air_drag:
                    spd = math.hypot(v_x, v_y)
                    v_x -= k_drag * v_x * spd
                    v_y -= k_drag * v_y * spd

                v_y += g
                x += v_x
                y += v_y

                max_h = max(max_h, start_y - y)  # высота над уровнем выстрела
                flight_dist = x - start_x

                if len(trail) == 0 or math.hypot(x - trail[-1][0], y - trail[-1][1]) > 5:
                    trail.append((int(x), int(y), t_flight))

                ball_rect = pygame.Rect(int(x) - ball_radius, int(y) - ball_radius,
                                        2 * ball_radius, 2 * ball_radius)

                if wall_visible and ball_rect.colliderect(wall_rect):
                    hit_wall = True
                    is_flying = False

                if math.hypot(x - target_pos[0], y - target_pos[1]) <= (ball_radius + target_radius):
                    hit_target = True
                    is_flying = False

                if y >= floor_y - ball_radius:
                    y = floor_y - ball_radius
                    is_flying = False

        # --- ОТРИСОВКА ---
        screen.fill((30, 30, 30))
        pygame.draw.line(screen, (255, 255, 255), (0, floor_y), (WIDTH, floor_y), 3)

        if wall_visible:
            pygame.draw.rect(screen, (140, 140, 140), wall_rect)
            pygame.draw.rect(screen, (200, 200, 200), wall_rect, 2)

        pygame.draw.circle(screen, (255, 50, 50), target_pos, target_radius)
        pygame.draw.circle(screen, (255, 255, 255), target_pos, target_radius - 8)
        pygame.draw.circle(screen, (255, 50, 50), target_pos, target_radius - 16)

        # Фантом траектории (тот же пробный выстрел, что использует автоприцел)
        if not is_flying:
            key = (angle_deg, velocity, current_planet, use_air_drag, wall_visible, wall_moving,
                   wall_dir, wall_rect.x, wall_rect.y, wall_rect.height, tuple(target_pos))
            if key != phantom_key:
                phantom_pts, _ = simulate_flight(angle_deg, velocity)
                phantom_key = key
            for p in phantom_pts:
                pygame.draw.circle(screen, (100, 100, 100), p, 2)

        trail_color = (255, 165, 0) if use_air_drag else (200, 255, 200)
        for pos in trail:
            pygame.draw.circle(screen, trail_color, (pos[0], pos[1]), 3)

        # Пушка
        angle_rad = math.radians(angle_deg)
        barrel_length, half_width = 55, 10
        dx, dy = math.cos(angle_rad), -math.sin(angle_rad)
        nx, ny = math.sin(angle_rad), math.cos(angle_rad)

        p1 = (start_x - nx * half_width, start_y - ny * half_width)
        p2 = (start_x + nx * half_width, start_y + ny * half_width)
        p3 = (start_x + barrel_length * dx + nx * half_width, start_y + barrel_length * dy + ny * half_width)
        p4 = (start_x + barrel_length * dx - nx * half_width, start_y + barrel_length * dy - ny * half_width)

        pygame.draw.polygon(screen, (120, 120, 120), [p1, p2, p3, p4])
        pygame.draw.circle(screen, (70, 70, 70), (int(start_x), int(start_y) + 5), 22)
        pygame.draw.circle(screen, (150, 150, 150), (int(start_x), int(start_y) + 5), 8)

        # Снаряд
        ball_color = (255, 215, 0) if hit_target else (255, 70, 70) if hit_wall else (0, 255, 128)
        if is_flying or trail:
            pygame.draw.circle(screen, ball_color, (int(x), int(y)), ball_radius)

        # --- ИНТЕРФЕЙС И СТАТИСТИКА (в метрах и секундах) ---
        g_ms2 = PLANETS[current_planet]["g"]
        screen.blit(
            font.render(f"Угол: {angle_deg:.1f}° | Скорость: {velocity:.1f} м/с | "
                        f"{current_planet} (g = {g_ms2:.2f} м/с²)", True, (255, 255, 255)),
            (20, 15))
        air_surf = font.render(f"Воздух [A]: {'ВКЛ' if use_air_drag else 'ВЫКЛ'}", True,
                               (255, 165, 0) if use_air_drag else (150, 250, 150))
        screen.blit(air_surf, (20, 45))
        screen.blit(font.render(f"Ускорение времени [T]: ×{WARP_LEVELS[warp_idx]}", True, (200, 200, 200)),
                    (20 + air_surf.get_width() + 30, 45))

        stat_text = (f"H_max: {max_h / PX_PER_M:.1f} м | Дальность: {flight_dist / PX_PER_M:.1f} м | "
                     f"Время: {t_flight * DT:.2f} с")
        screen.blit(font.render(stat_text, True, (0, 200, 255)), (20, 75))

        if message_timer > 0:
            screen.blit(font.render(message_text, True, message_color), (20, 105))

        # Подсказки ниже линии земли (floor_y = 640)
        screen.blit(controls_surf_1, (20, 650))
        screen.blit(controls_surf_2, (20, 675))

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)  # Pygbag: без этой строки (именно с нулём) браузер зависнет


# Точка входа. После этой строки ничего писать нельзя (в том числе pygame.quit() и sys.exit()).
asyncio.run(main())
